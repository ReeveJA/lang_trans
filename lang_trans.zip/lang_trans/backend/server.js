const express = require('express')
const bodyParser  = require('body-parser')
const dict = require('./dict')

const app = express()

const port = 3000

app.use(bodyParser.json())

app.get('/', (req, res) => {
    res.send('Language Translator')
})

app.post('/api/translate', (req, res) => {
    try {
        const { text } = req.body
        const words = text.toLowerCase().split(' ')
        const translatedWords = words.map(word => dict[word] || word)
        const translatedText = translatedWords.join(' ')
        res.json({translatedText: translatedText})
    } catch (error) {
        console.log('Translation error', error)
        res.status(500).json({translatedText: 'Error translating text.'})
    }
})

app.get('*', (req, res) => {
    res.send('Page not found')
})

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`)
})