const dict = {
    hello: 'hola',
    world: 'mundo',
    goodbye: 'adios',
    ladies: 'mujeres',
    fucker: 'puta',
    mother: 'madre',
    my: 'mi',
    name: 'nom',
    is: 'es'
}

module.exports = dict