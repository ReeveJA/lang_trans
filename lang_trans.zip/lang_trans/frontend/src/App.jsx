import React from 'react'
import Translator from './components/translator/Translator'

const App = () => {
  return (
    <main>
      <Translator />
    </main>
  )
}

export default App