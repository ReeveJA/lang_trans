import React, { useState } from 'react'

const Translator = () => {
    const [inputText, setInputText] = useState('')
    const [translatedText, setTranslatedText] = useState('')

    const handleInputChange = (e) => {
        setInputText(e.target.value)
    }

    const handleTranslate = async () => {
        const res = await fetch('/api/translate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ text: inputText})
        })

        if (res.ok) {
            const data = await res.json()
            setTranslatedText(data.translatedText)
        } else {
            setTranslatedText('Error translating text.')
        }
    }

  return (
    <>
        <form className='translator container mx-auto p-4 max-w-lg flex flex-col justify-center' onSubmit={(e) => {
            e.preventDefault()
            handleTranslate()
        }}>
            <label
                className='text-2xl font-semibold text-center'
                htmlFor='inputText'>Text:
            </label>
            <textarea
                className='border-2' 
                id='inputText' 
                rows={10} 
                cols={20}
                value={inputText}
                onChange={handleInputChange}>
            </textarea>

            <button className='mt-2 mb-4 rounded-lg p-2 bg-red-400 text-2xl text-white'>Translate</button>

            <label
                className='text-2xl font-semibold text-center mt-12'
                htmlFor='translatedText'>Translated:
            </label>
            <textarea 
                className='border-2'
                id='translatedText' 
                rows={10} 
                cols={20}
                value={translatedText}
                readOnly>
            </textarea>

            
        </form>
    </>
  )
}

export default Translator